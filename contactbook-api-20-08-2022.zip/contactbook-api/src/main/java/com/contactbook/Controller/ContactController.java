package com.contactbook.Controller;


import com.contactbook.entity.Contact;
import com.contactbook.repositoy.ContactRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/contact")
@RequiredArgsConstructor
@CrossOrigin("*")
public class ContactController {

    @Autowired
    private ContactRepository repository;

    @PostMapping(value = "/save")
    public Contact save(@RequestBody Contact contact) {

        return repository.save(contact);
    }

}
