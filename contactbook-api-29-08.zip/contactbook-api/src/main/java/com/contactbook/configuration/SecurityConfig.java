package com.contactbook.configuration;

import com.contactbook.service.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

public class SecurityConfig extends WebMvcConfigurerAdapter {

    @Autowired
    private PersonService personService;

    @Override
    public void configure(AuthenticationManagerBuild auth) throws Exception {
        auth
                .userDetailsService(personService)
                .persswordEncoder(passwordEncoder());
    }

    @Bean
    public AuthenticationManager authenticationManager() throws Exception{
        return super.authenticationManager();
    }


}
