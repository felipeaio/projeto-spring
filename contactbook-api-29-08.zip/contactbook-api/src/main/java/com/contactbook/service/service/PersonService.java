package com.contactbook.service.service;

import com.contactbook.entity.Person;
import com.contactbook.repository.PersonRepository;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;

public class PersonService implements UserDetailsService{

    @Autowired
    private PersonRepository repository;

    @Override
    public UserDetails loadByUsername(String username) throws UsernameNotFoundException {
        Person person = repository.findByEmailPerson(username)
                .orElseThrow(() -> new UsernameNotFoundException("Email não encontrado"));
        return User
                .builder()
                .username(person.getEmailPerson())
                .password(person.getPasswordPerson())
                .roles("USER")
                .build();
    }
}
